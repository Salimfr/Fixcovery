from django import template
from django.shortcuts import render, HttpResponseRedirect

from htmlcss.models import Product



register = template.Library()

@register.filter(name='is_in_cart')
def is_in_cart(product):
    print(product)
    return True

def Cart(View):
    def get(self, request):
        ids = list(request.session.get('cart').keys())
        products =  Product.get_products_by_id(ids)
        print(products)
        return render(request, "cart.html", {'products':products})


@register.filter(name='cart_quantity')
def cart_quantity(products, cart):
    print('salim')
    keys = cart.keys()
    for id in keys:
        if id == products.id:
            return cart.get(id)
        return 0

@register.filter(name='price_total')
def price_total(product, cart):
    return product.price * cart_quantity(product, cart)

@register.filter(name='total_cart_price')
def total_cart_price(products, cart):
    sum = 0
    for p in products:
        sum += price_total(p, cart)
    return sum



