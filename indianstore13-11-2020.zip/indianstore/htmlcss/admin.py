from django.contrib import admin
from .models import Product
from .models import Categories
from .models import Customer
from .models import Order

# Register your models here.
#from .models import PostAdd
#from .models import UserAdd


#admin.site.register(PostAdd)
#admin.site.register(UserAdd)

class AdminProduct(admin.ModelAdmin):
    list_display = ['name','price','catid','description','image']

class AdminCategories(admin.ModelAdmin):
    list_display = ['name']

class AdminCustomer(admin.ModelAdmin):
    list_display = ['first_name','last_name','email','phone','password']

class AdminOrder(admin.ModelAdmin):
    list_display = ['product','customer','quantity','price','date']


admin.site.register(Product, AdminProduct)
admin.site.register(Categories, AdminCategories)
admin.site.register(Customer, AdminCustomer)
admin.site.register(Order, AdminOrder)
