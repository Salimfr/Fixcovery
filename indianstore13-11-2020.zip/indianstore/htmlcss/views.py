from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages

from htmlcss.models import PostAdd
from htmlcss.models import SignUp
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse
from htmlcss.models import Product
from htmlcss.models import Categories
from htmlcss.models import Customer
from htmlcss.models import Order
from django.contrib.auth.hashers import  make_password, check_password
from mysite.middlewares.auth import auth_middleware
from django.utils.decorators import method_decorator




'''def Insertrecord(request):
    if request.method == 'POST':
        if request.POST.get('pid') and request.POST.get('mdate') and request.POST.get('mtime') and request.POST.get('mtitle') and request.POST.get('mdesc') and request.POST.get('mnotes') and request.POST.get('mvideo'):
            saverecord=methodInsert()
            saverecord.pid = request.POST.get('pid')
            saverecord.mdate = request.POST.get('mdate')
            saverecord.mtime = request.POST.get('mtime')
            saverecord.mtitle = request.POST.get('mtitle')
            saverecord.mdesc = request.POST.get('mdesc')
            saverecord.mnotes = request.POST.get('mnotes')
            saverecord.mvideo = request.POST.get('mvideo')
            saverecord.save()
            messages.success(request, 'Record Saved Successfully')
            return render(request, "uploadpost.html")
    else:
        return render(request, "uploadpost.html")'''

'''def Insertrecord(request):
    if request.method == 'POST':
        if request.POST.get('ptitle') and request.POST.get('pdesc') and request.POST.get('mtitle') and request.POST.get('mdesc') and request.POST.get('stext'):
            savepost = temppostInsert()
            savepost.ptitle = request.POST.get('ptitle')
            savepost.pdesc = request.POST.get('pdesc')
            savepost.save()
            savemethod = methodInsert()
            savemethod.mtitle = request.POST.get('mtitle')
            savemethod.mdesc = request.POST.get('mdesc')
            savemethod.save()
            #savesteps = StepsInsert()
            #savesteps.stext = request.POST.get('stext')
            #savesteps.save()


            messages.success(request, 'Record Saved Successfully')
            return render(request, "uploadpost.html")
    else:
        return render(request, "uploadpost.html")'''


def PostAdd1(request):
    if request.method == 'POST':
        savepost = PostAdd()
        savepost.postid = request.POST.get('postid')
        savepost.userid = request.POST.get('userid')
        savepost.methid = request.POST.get('methid')
        savepost.posttitle = request.POST.get('posttitle')
        savepost.postdesc = request.POST.get('postdesc')
        savepost.methtitle = request.POST.get('methtitle')
        savepost.methdesc = request.POST.get('methdesc')
        savepost.step1 = request.POST.get('step1')
        savepost.s2 = request.POST.get('s2')
        savepost.s3 = request.POST.get('s3')
        savepost.s4 = request.POST.get('s4')
        savepost.s5 = request.POST.get('s5')
        savepost.s6 = request.POST.get('s6')
        savepost.s7 = request.POST.get('s7')
        savepost.s8 = request.POST.get('s8')
        savepost.s9 = request.POST.get('s9')
        savepost.s10 = request.POST.get('s10')
        savepost.s11 = request.POST.get('s11')
        savepost.s12 = request.POST.get('s12')
        savepost.s13 = request.POST.get('s13')
        savepost.s14 = request.POST.get('s14')
        savepost.s15 = request.POST.get('s15')
        savepost.s16 = request.POST.get('s16')
        savepost.s17 = request.POST.get('s17')
        savepost.s18 = request.POST.get('s18')
        savepost.s19 = request.POST.get('s19')
        savepost.s20 = request.POST.get('s20')
        savepost.s21 = request.POST.get('s21')
        savepost.s22 = request.POST.get('s22')
        savepost.s23 = request.POST.get('s23')
        savepost.s24 = request.POST.get('s24')
        savepost.s25 = request.POST.get('s25')
        savepost.save()
        messages.success(request, 'Record Saved Successfully')
        return render(request, "index.html")

    else:
        return render(request, "index.html")


def signup(request):
    if request.method == 'POST':
        savepost = Customer()
        savepost.first_name = request.POST.get('first_name')
        savepost.last_name = request.POST.get('last_name')
        savepost.phone = request.POST.get('phone')
        savepost.email = request.POST.get('email')
        savepost.password = request.POST.get('password')
        savepost.save()
        messages.success(request, 'Record Saved Successfully')
        return render(request, "index.html")
    else:
        return render(request, "index.html")

def checkout(request):
    if request.method == 'POST':
        saveOrder = Order
        saveOrder.product = request.POST.get("product")
        saveOrder.customer = request.POST.get("customer")
        saveOrder.quantity = request.POST.get("quantity")
        saveOrder.price = request.POST.get("price")
        saveOrder.address=request.POST.get("address")
        saveOrder.phone = request.POST.get("phone")
        saveOrder.date=request.session.get("date")
        orders = Order.objects.all()
        return render(request, "orders.html", {'orders':orders})
    else:
        return redirect('homepage')

@auth_middleware(auth_middleware)
def order(request):
    orders = Order.objects.all().order_by('-date')
    print('salim' , orders)
    return render(request, 'orders.html', {'orders': orders})



def signupsave(request):
    if request.method == 'POST':
        savepost = Customer()
        savepost.first_name = request.POST.get('first_name')
        savepost.last_name = request.POST.get('last_name')
        savepost.phone = request.POST.get('phone')
        savepost.email = request.POST.get('email')
        savepost.password = request.POST.get('password')
        value = {
            'first_name': savepost.first_name,
            'last_name': savepost.last_name,
            'phone': savepost.phone,
            'email': savepost.email,
        }
        error_message = None
        if (not savepost.first_name):
            error_message = "First Name Required !!"
        elif len(savepost.first_name) < 4:
            error_message = "First Name must be minimum 4 character long !!"
        elif (not savepost.last_name):
            error_message = "Last Name Required !!"
        elif len(savepost.last_name) < 4:
            error_message = "Last Name must be minimum 4 character long !!"
        elif (not savepost.phone):
            error_message = "Phone Number Required !!"
        elif len(savepost.phone) < 8:
            error_message = "Phone Number must be minimum 8 number long !!"
        elif (not savepost.email):
            error_message = "Email Required !!"
        elif (not savepost.password):
            error_message = "Password Required !!"
        elif len(savepost.password) < 6:
            error_message = "Password must be minimum 6 character or numbers !!"
        elif Customer.objects.filter(email=request.POST['email']).exists():
            error_message = "Email Address already registererd..."
        if not error_message:
            savepost.password = make_password(savepost.password)
            savepost.save()
            return redirect('homepage')
        else:
            data = {
                'error': error_message,
                'values': value
            }
            return render(request, "signup.html", data)

def loginp(request):
        return redirect(request,'login.html')


def showrecord1(request):
    context = {}
    if request.method == "POST":
        email = request.POST['email']
        pwd = request.POST['pwd']
        user = authenticate(request, email=email, pwd=pwd)
        if user:
            context["error"] = "Provide Valid Credential !!"
            return render(request, "loginpage.html", context)

        else:
            login(request, user)
    else:
        return render(request, "loginpage.html")


def loginpage(request):
    if request.method == "POST":
        email= request.POST.get('email')

        password = request.POST.get('password')

        print(email, password)
        customer = Customer.get_customer_by_email(email)
        print(customer)

        error_message = None

        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer'] = customer.id

                return redirect('homepage')
            else:
                error_message = "Email or Password Invalid"
        else:
            error_message = "Email or Password Invalid"

        return render(request,"loginpage.html", {'error': error_message})
    else:
        return render(request, "loginpage.html")

def logoutp(request):
    request.session.clear()
    return redirect('homepage')

def cart(request):
    products = Product.objects.all()
    return render(request, "cart.html", {'products': products})


def signuppage(request):
    return render(request, "signuppage.html")


def home(request):
    return render(request, 'home.html')

def index(request):
    product = request.POST.get('product')
    remove = request.POST.get('remove')
    print(product)
    cart=request.session.get('cart')
    if cart:
        quantity = cart.get(product)
        if quantity:
            if remove:
                if cart[product]<=1:
                    cart.pop(product)
                else:
                    cart[product] = cart[product] - 1
            else:
                cart[product] = cart[product] + 1
        else:
            cart[product] = 1
    else:
        cart={}
        cart[product]=1
    request.session['cart']=cart
    print(request.session['cart'])
    products = Product.get_all_products()
    categories = Categories.get_all_categories()
    print(request.GET)
    categoryID = request.GET.get('category')
    print(categoryID)
    if categoryID:
        products = Product.get_all_products_by_categoryid(categoryID)
    else:
        Product.get_all_products()
    data = {}
    data['products'] = products
    data['categories'] = categories
    print('your are : ', request.session.get('email'))
    return render(request, 'index.html', data)


def signup(request):
    return render(request, 'signup.html')


def about(request):
    return render(request, 'about.html')


# Contact

def contact(request):
    return render(request, 'contact.html')


def dashboard(request):
    return render(request, 'dashboard.html')
