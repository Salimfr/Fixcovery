from django.db import models
from .category import Category


class Tabletest(models.Model):
    category1 = models.CharField(max_length=20, null=None, blank="True")
    category2 = models.CharField(max_length=20, null=None, blank="True")
    category3 = models.CharField(max_length=20, null=None, blank="True")
    category4 = models.CharField(max_length=20, null=None, blank="True")
    category5 = models.CharField(max_length=20, null=None, blank="True")
    category6 = models.CharField(max_length=20, null=None, blank="True")
    category7 = models.CharField(max_length=20, null=None, blank="True")
    category8 = models.CharField(max_length=20, null=None, blank="True")
    category9 = models.CharField(max_length=20, null=None, blank="True")
    category10 = models.CharField(max_length=20, null=None, blank="True")


