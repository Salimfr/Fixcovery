from django.db import models

class UserAdd(models.Model):
    userid = models.CharField(max_length=255)
    userfname = models.CharField(max_length=255)
    userlname = models.CharField(max_length=255)
    userdob = models.CharField(max_length=255)
    username = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    useremail = models.CharField(max_length=255)
    useraddress = models.CharField(max_length=255)
    usercity = models.CharField(max_length=255)
    usercountry = models.CharField(max_length=255)
    usertel = models.CharField(max_length=255)
    useraccno = models.CharField(max_length=255)
    useriban = models.CharField(max_length=255)
    userbankname = models.CharField(max_length=255)
    userbranchname = models.CharField(max_length=255)
    class Meta:
        db_table = "useradd"



class PostAdd(models.Model):
    postid = models.CharField(max_length=255, default='SOME STRING')
    userid = models.CharField(max_length=255, default='SOME STRING')
    methid = models.CharField(max_length=255, default='SOME STRING')
    posttitle = models.CharField(max_length=255, default='SOME STRING')
    postdesc = models.CharField(max_length=255, default='SOME STRING')
    methtitle = models.CharField(max_length=255, default='SOME STRING')
    methdesc = models.CharField(max_length=255, default='SOME STRING')
    step1 = models.CharField(max_length=255, default='SOME STRING')
    step2 = models.CharField(max_length=255, default='SOME STRING')
    step3 = models.CharField(max_length=255, default='SOME STRING')
    step4 = models.CharField(max_length=255, default='SOME STRING')
    step5 = models.CharField(max_length=255, default='SOME STRING')
    step6 = models.CharField(max_length=255, default='SOME STRING')
    step7 = models.CharField(max_length=255, default='SOME STRING')
    step8 = models.CharField(max_length=255, default='SOME STRING')
    step9 = models.CharField(max_length=255, default='SOME STRING')
    step10 = models.CharField(max_length=255, default='SOME STRING')
    step11 = models.CharField(max_length=255, default='SOME STRING')
    step12 = models.CharField(max_length=255, default='SOME STRING')
    step13 = models.CharField(max_length=255, default='SOME STRING')
    step14 = models.CharField(max_length=255, default='SOME STRING')
    step15 = models.CharField(max_length=255, default='SOME STRING')
    step16 = models.CharField(max_length=255, default='SOME STRING')
    step17 = models.CharField(max_length=255, default='SOME STRING')
    step18 = models.CharField(max_length=255, default='SOME STRING')
    step19 = models.CharField(max_length=255, default='SOME STRING')
    step20 = models.CharField(max_length=255, default='SOME STRING')
    step21 = models.CharField(max_length=255, default='SOME STRING')
    step22 = models.CharField(max_length=255, default='SOME STRING')
    step23 = models.CharField(max_length=255, default='SOME STRING')
    step24 = models.CharField(max_length=255, default='SOME STRING')
    step25 = models.CharField(max_length=255, default='SOME STRING')
    class Meta:
        db_table = "postadd"


class SignUp(models.Model):
    uname = models.CharField(max_length=255, default='SOME STRING')
    email = models.CharField(max_length=255, default='SOME STRING')
    pwd = models.CharField(max_length=255, default='SOME STRING')
    class Meta:
        db_table = "signup"

class Product(models.Model):
    name=models.CharField(max_length=50)
    price = models.IntegerField(default=0)
    description = models.CharField(max_length=200)
    image = models.ImageField(upload_to='uploads/products')
    class Meta:
        db_table = "product"

