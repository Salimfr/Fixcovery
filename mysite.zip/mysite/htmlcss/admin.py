from django.contrib import admin

# Register your models here.
from .models import PostAdd
from .models import UserAdd
from .models import Product

admin.site.register(PostAdd)
admin.site.register(UserAdd)
admin.site.register(Product)
