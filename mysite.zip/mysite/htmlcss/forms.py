from django import forms
#from htmlcss.models import Employee
#from htmlcss.models import Postfixt
from htmlcss.models import PostAdd

#class EmployeeForm(forms.ModelForm):
#    class Meta:
#        model = Employee
#        fields = "__all__"

#class PostfixForm(forms.ModelForm):
#    class Meta:
#        model = Postfixt
#        fields = "__all__"


class PostAddForm(forms.ModelForm):
    class Meta:
        model = PostAdd
        fields = "__all__"