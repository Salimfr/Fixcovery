from django.shortcuts import render, redirect
from login.forms import UserAddForm
from login.forms import PostAddForm
from login.models import UserAdd
from login.models import PostAdd
from django.contrib import messages
from django.contrib import auth
from django.contrib.auth.models import User

'''def showrecord(request):
    if request.method == 'POST':
        form = UserAddForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                messages.success(request, 'Record Saved Successfully')
                return redirect()
            except:
                pass
    else:
        form = UserAddForm()
    return render(request,'register.html', {'form':form} )'''


def useradding(request):
    if request.method == 'POST':
        saveuser = UserAdd()
        saveuser.userid = request.POST.get('userid')
        saveuser.userfname = request.POST.get('userfname')
        saveuser.userlname = request.POST.get('userlname')
        saveuser.userdob = request.POST.get('userdob')
        saveuser.username = request.POST.get('username')
        saveuser.password = request.POST.get('password')
        saveuser.useremail = request.POST.get('useremail')
        saveuser.useraddress = request.POST.get('useraddress')
        saveuser.usercity = request.POST.get('usercity')
        saveuser.usercountry = request.POST.get('usercountry')
        a= request.POST.get('useraddress') + "*#*" + request.POST.get('usercity') + "*#*" + request.POST.get('usercountry')
        b = "Using cmd @@@ lets see how to do this @@@ #s#step 1#s# #s#step 2#s# #s#imge <img #s# #m# Using Registry @@@ lets see ! step 1"
        saveuser.usertel = request.POST.get('usertel')
        saveuser.useraccno = request.POST.get('useraccno')
        saveuser.useriban = request.POST.get('useriban')
        saveuser.userbankname = b
        saveuser.userbranchname = a
        saveuser.save()
        messages.success(request, 'Record Saved Successfully')
        return render(request, "register.html")
    else:
        return render(request, "register.html")


def home(request):
    if request.method == "POST":
        user = auth.authenticate(username=request.POST['username'], password=request.POST['password'])
        if user is not None:
            auth.login(request, user)
            return render(request, "uploadpage.html")
        else:
            return render(request, "home.html", {'error' : "Invalid Login"})
    else:
        return render(request, "home.html")

'''def home(request):

    return render(request, "home.html")'''

def signup(request):
    if request.method=="POST":
        if request.POST['password']==request.POST['passwordagain']:
            try:
                user = User.objects.get(username = request.POST['username'])
                return render(request, "register.html", {'error': "Username already taken"})
            except User.DoesNotExist:
                user = User.objects.create_user(username=request.POST['username'], password = request.POST['password'])
                return redirect(home)
        else:
            return render(request, "register.html", {'error' : "Password Don't Match"} )
    else:
        return render(request, "register.html")

def logout(request):
    auth.logout(request)
    return redirect(home)

def update(request):
    if request.method == "POST":
        r1 = request.POST.get('m1',None)
        r2 = request.POST.get('m1s1', None)
        r3 = request.POST.get('m1s2', None)

        print("#m#"+r1+"#s#"+r2+"#s#"+r3)
        return render(request, "register.html")
    else:
        return render(request, "update.html")

def test(request):
        return render(request, "test.html")


def postpage(request):
    return render(request, "postpage.html")