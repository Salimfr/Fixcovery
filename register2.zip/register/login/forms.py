from django import forms
from login.models import UserAdd
from login.models import PostAdd

class UserAddForm(forms.ModelForm):
    class Meta:
        model = UserAdd
        fields = "__all__"

class PostAddForm(forms.ModelForm):
    class Meta:
        model = PostAdd
        fields = "__all__"