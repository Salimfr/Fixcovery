function descbuttonchange()
		{
	  		var x = document.getElementById("adddesc");

	  		if (x.innerHTML.includes("Remove"))
	  		{
	  			//includes check if it's add or remove
	    		x.innerHTML = "<i class='fas fa-plus'></i> Add Description";
				//x.style.cssText  = "border-color: #0275d8;";
				document.getElementById("metinput").value="";
	  		}
	  		else
	  		{
	    		x.innerHTML = "<i class='fas fa-times'></i> Remove Description";
	    		document.getElementsById("input").value="";
	    		//x.style.cssText  = "border-color: #c21919; color:#c21919;";
	  		}
		}

		function notebtnchange() {
	  		var x = document.getElementById("addnote");

	  		if (x.innerHTML.includes("Remove"))
	  		{
	  			//includes check if it's add or remove
	    		x.innerHTML = "<i class='fas fa-exclamation-triangle'></i> Add Note";
				//x.style.cssText  = "border-color: #0275d8;";
				document.getElementById("noteinput").value="";
	  		}
	  		else
	  		{
	    		x.innerHTML = "<i class='fas fa-exclamation-triangle'></i> Remove Note";
	    		document.getElementsById("input").value="";
	    		//x.style.cssText  = "border-color: #c21919; color:#c21919;";
	  		}
		}

		function videobtnchange()
		{
	  		var x = document.getElementById("addvideo");

	  		if (x.innerHTML.includes("Remove"))
	  		{
	  			//includes check if it's add or remove
	    		x.innerHTML = "<i class='fab fa-youtube'></i> Add Video";
				//x.style.cssText  = "border-color: #0275d8;";
				document.getElementById("noteinput").value="";
	  		}
	  		else
	  		{
	    		x.innerHTML = "<i class='fab fa-youtube'></i> Remove Video";
	    		document.getElementById("input").value="";
			    //x.style.cssText  = "border-color: #c21919; color:#c21919;";
			  }
			}

			function searchvideourl()
			{
				//var videospot = document.getElementsByClassName("videocanvas");
				var urlinput = document.getElementById("videourlinput").value;

				var videospot = document.getElementById('videocanvas');
  				videospot.innerHTML = '<iframe src='urlinput' frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
			}

			function stepadd()
			{
	  			let menu = document.querySelector('#stepblock');
        		let clonedMenu = menu.cloneNode(true);

        		var numofsteps = document.querySelectorAll(".stepclass");
	    		var maximumstepcount = parseInt(numofsteps.length, 10)

        		clonedMenu.id = 'stepblock' + (maximumstepcount+1);
        		document.getElementById("forsteps").appendChild(clonedMenu);

        		//change step number in each repetition
        		var changestepnumber = clonedMenu.getElementsByClassName("stepcircle")[0];
        		changestepnumber.innerHTML = (maximumstepcount + 1);

        		//change step number inside box
        		var changestepnum = clonedMenu.getElementsByClassName("titlelabel")[0];
       			changestepnum.innerHTML = "Step " + (maximumstepcount + 1);

        		//remove any existing texts
        		var refreshtext = clonedMenu.getElementsByClassName("inputboxes")[0];
        		refreshtext.value = "";

        		//remove any existing texts
        		var refreshtext = clonedMenu.getElementsByClassName("inputboxes")[0];
        		refreshtext.value = "";

        		//enable removestepbutton state as active
        		var removestepbtn = clonedMenu.getElementsByClassName("removestepbtn")[0];
        		removestepbtn.disabled = false;
        		removestepbtn.id = "removebuttonid" + (maximumstepcount+1);

        		var element = document.getElementById("addstepbtn");
    			//element.parentNode.removeChild(element);
    			i++;
			}

			function removestep(elemid)
			{
				//id is for which step number is selected to remove
				//elemid = "removebuttonid1"

				var num = elemid.replace(/\D/g, "");

				var element = document.getElementById("stepblock" + num);
				element.parentNode.removeChild(element);

	    		var numofsteps = document.querySelectorAll(".stepclass");
	    		var maximumstepcount = parseInt(numofsteps.length, 10)


				stepfixer();

			}

			function stepfixer()
			{
				var numofsteps = document.querySelectorAll(".stepclass");
	   			var maximumstepcount = parseInt(numofsteps.length, 10)



	    		for (j=1; j < maximumstepcount; j++)
	    		{
	    			numofsteps[j].id = "stepblock" + (j+1);

	    			//Fixing the step display number
	    			var newelement = numofsteps[j].getElementsByClassName("stepcircle")[0];
            		newelement.innerHTML = j+1;

	    			//Fixing the remove button id
            		var changebuttonid = numofsteps[j].querySelector(".removestepbtn");
          			changebuttonid.id = "removebuttonid" + (j+1);

	    			//Fixing the step number inside input
          			var changeinnerstep = numofsteps[j].querySelector(".titlelabel");
          			changeinnerstep.innerHTML = "Step " + (j+1);
	    			//alert("numofsteps[j].id")
				}
			}
