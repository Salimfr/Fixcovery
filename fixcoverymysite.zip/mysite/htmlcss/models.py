from django.db import models

'''class methodInsert(models.Model):
    pid = models.CharField(max_length=100)
    mdate = models.CharField(max_length=100)
    mtime = models.CharField(max_length=100)
    mtitle = models.CharField(max_length=100)
    mdesc = models.CharField(max_length=100)
    mnotes = models.CharField(max_length=100)
    mvideo = models.CharField(max_length=100)

    class Meta:
        db_table = "method"'''

#class postInsert(models.Model):
 #   ptitle = models.CharField(max_length=100)
#   pdesc = models.CharField(max_length=100)


 #   class Meta:
  #      db_table = "post"


'''class methodInsert(models.Model):
    mtitle = models.CharField(max_length=100)
    mdesc = models.CharField(max_length=100)


    class Meta:
        db_table = "method"



#class Employee (models.Model):
#    eid = models.CharField(max_length=20)
#    ename = models.CharField(max_length=100)
#    eemail = models.EmailField()
#    econtact = models.CharField(max_length=15)
#    class Meta:
#        db_table = "employee"


class Postfixt(models.Model):
    ptitle = models.CharField(max_length=255)
    pname = models.CharField(max_length=255)
    pdesc = models.CharField(max_length=255)
    mtitle = models.CharField(max_length=255)
    mdesc = models.CharField(max_length=255)
    sone = models.CharField(max_length=255)
    stwo = models.CharField(max_length=255)
    sthree = models.CharField(max_length=255)
    class Meta:
        db_table = "postfix"'''

class PostAdd(models.Model):
    postid = models.CharField(max_length=255)
    userid = models.CharField(max_length=255)
    methid = models.CharField(max_length=255)
    posttitle = models.CharField(max_length=255)
    postdesc = models.CharField(max_length=255)
    methtitle = models.CharField(max_length=255)
    methdesc = models.CharField(max_length=255)
    s1 = models.CharField(max_length=255)
    s2 = models.CharField(max_length=255)
    s3 = models.CharField(max_length=255)
    s4 = models.CharField(max_length=255)
    s5 = models.CharField(max_length=255)
    s6 = models.CharField(max_length=255)
    s7 = models.CharField(max_length=255)
    s8 = models.CharField(max_length=255)
    s9 = models.CharField(max_length=255)
    s10 = models.CharField(max_length=255)
    s11 = models.CharField(max_length=255)
    s12 = models.CharField(max_length=255)
    s13 = models.CharField(max_length=255)
    s14 = models.CharField(max_length=255)
    s15 = models.CharField(max_length=255)
    s16 = models.CharField(max_length=255)
    s17 = models.CharField(max_length=255)
    s18 = models.CharField(max_length=255)
    s19 = models.CharField(max_length=255)
    s20 = models.CharField(max_length=255)
    s21 = models.CharField(max_length=255)
    s22 = models.CharField(max_length=255)
    s23 = models.CharField(max_length=255)
    s24 = models.CharField(max_length=255)
    s25 = models.CharField(max_length=255)

    class Meta:
        db_table = "postadd"



#class StepsInsert(models.Model):
#    name = models.CharField(max_length=255)
#    class Meta:
#        db_table = "testing"

'''class temppostInsert(models.Model):
    postid = models.CharField(max_length=100)
    ptitle = models.CharField(max_length=100)
    pdesc = models.CharField(max_length=100)
    mtitle1 = models.CharField(max_length=100)
    mdesc1 = models.CharField(max_length=100)
    s1 = models.CharField(max_length=100)
    s2 = models.CharField(max_length=100)



    class Meta:
        db_table = "temppost"'''