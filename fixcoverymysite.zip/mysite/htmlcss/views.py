from django.shortcuts import render
#from htmlcss.models import postInsert
#from htmlcss.models import methodInsert
#from htmlcss.models import StepsInsert
#from htmlcss.models import temppostInsert
from django.contrib import messages
#from htmlcss.models import Employee
#from htmlcss.models import Postfixt
from htmlcss.models import PostAdd


'''def Insertrecord(request):
    if request.method == 'POST':
        if request.POST.get('pid') and request.POST.get('mdate') and request.POST.get('mtime') and request.POST.get('mtitle') and request.POST.get('mdesc') and request.POST.get('mnotes') and request.POST.get('mvideo'):
            saverecord=methodInsert()
            saverecord.pid = request.POST.get('pid')
            saverecord.mdate = request.POST.get('mdate')
            saverecord.mtime = request.POST.get('mtime')
            saverecord.mtitle = request.POST.get('mtitle')
            saverecord.mdesc = request.POST.get('mdesc')
            saverecord.mnotes = request.POST.get('mnotes')
            saverecord.mvideo = request.POST.get('mvideo')
            saverecord.save()
            messages.success(request, 'Record Saved Successfully')
            return render(request, "uploadpost.html")
    else:
        return render(request, "uploadpost.html")'''

'''def Insertrecord(request):
    if request.method == 'POST':
        if request.POST.get('ptitle') and request.POST.get('pdesc') and request.POST.get('mtitle') and request.POST.get('mdesc') and request.POST.get('stext'):
            savepost = temppostInsert()
            savepost.ptitle = request.POST.get('ptitle')
            savepost.pdesc = request.POST.get('pdesc')
            savepost.save()
            savemethod = methodInsert()
            savemethod.mtitle = request.POST.get('mtitle')
            savemethod.mdesc = request.POST.get('mdesc')
            savemethod.save()
            #savesteps = StepsInsert()
            #savesteps.stext = request.POST.get('stext')
            #savesteps.save()


            messages.success(request, 'Record Saved Successfully')
            return render(request, "uploadpost.html")
    else:
        return render(request, "uploadpost.html")'''


def PostAdd1(request):
    if request.method == 'POST':

            savepost = PostAdd()
            savepost.postid = request.POST.get('postid')
            savepost.userid = request.POST.get('userid')
            savepost.methid = request.POST.get('methid')
            savepost.posttitle = request.POST.get('posttitle')
            savepost.postdesc = request.POST.get('postdesc')
            savepost.methtitle = request.POST.get('methtitle')
            savepost.methdesc = request.POST.get('methdesc')
            savepost.s1= request.POST.get('s1')
            savepost.s2 = request.POST.get('s2')
            savepost.s3 = request.POST.get('s3')
            savepost.s4 = request.POST.get('s4')
            savepost.s5 = request.POST.get('s5')
            savepost.s6 = request.POST.get('s6')
            savepost.s7 = request.POST.get('s7')
            savepost.s8 = request.POST.get('s8')
            savepost.s9 = request.POST.get('s9')
            savepost.s10 = request.POST.get('s10')
            savepost.s11 = request.POST.get('s11')
            savepost.s12 = request.POST.get('s12')
            savepost.s13 = request.POST.get('s13')
            savepost.s14 = request.POST.get('s14')
            savepost.s15 = request.POST.get('s15')
            savepost.s16 = request.POST.get('s16')
            savepost.s17 = request.POST.get('s17')
            savepost.s18 = request.POST.get('s18')
            savepost.s19 = request.POST.get('s19')
            savepost.s20 = request.POST.get('s20')
            savepost.s21 = request.POST.get('s21')
            savepost.s22 = request.POST.get('s22')
            savepost.s23 = request.POST.get('s23')
            savepost.s24 = request.POST.get('s24')
            savepost.s25 = request.POST.get('s25')
            savepost.save()
            messages.success(request, 'Record Saved Successfully')
            return render(request, "index.html")

    else:
        return render(request, "index.html")

def showrecord(request):

    steps = PostAdd.objects.filter(postid='12')
    return render(request, "postpage1.html", {'steps':steps})
