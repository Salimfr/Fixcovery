from django.contrib import admin
from django.urls import path
from .views.home import Index , store
from .views.signupp import Signupp
from .views.login import Login , logout
from .views.cartp import Cartp
from .views.checkout import CheckOut
from .views.orders import OrderView
from .views.adminp import AdminpView
from .views.product import ProductView
from .views.product import ProductSave
from .views.addcategory import AddCategorySave
from .views.pendingorder import PendingOrderView
from .middlewares.auth import  auth_middleware
from .views.edit import edit
from .views.update import update
from .views.deleteproduct import deleteproduct
from .views.completed import completed
from .views.message import messageto
from .views.purchase import purchase
from .views.addsupplier import addsupplier
from .views.cancelorder import cancelorder
from .views.contactus import contactus
from .views.test import Test
from .views.adminmain import adminmain
from .views.promotion import promotion
from .views.purchase import purchase
from .views.purchase import confirmpurchase
from .views.purchase import purchasereceive
from .views.purchase import purchasecancel

urlpatterns = [
    path('', Index.as_view(), name='homepage'),
    path('store', store , name='store'),
    path('signupp', Signupp.as_view(), name='signupp'),
    path('login', Login.as_view(), name='login'),
    path('logout', logout , name='logout'),
    path('cartp', auth_middleware(Cartp.as_view()) , name='cartp'),
    path('check-out', CheckOut.as_view() , name='checkout'),
    path('adminp', AdminpView.as_view(), name='adminp'),
    path('product', ProductView.as_view(), name='product'),
    path('addcategory', AddCategorySave, name='addcategory'),
    path('ProductSave', ProductSave, name='ProductSave'),
    path('orderpending', PendingOrderView.as_view(), name='orderpending'),
    path('orders', auth_middleware(OrderView.as_view()), name='orders'),
    path('edit/<int:id>', edit, name='edit'),
    path('update/<int:id>', update, name='update'),
    path('deleteproduct/<int:id>', deleteproduct, name='deleteproduct'),
    path('completed/<int:id>', completed, name='completed'),
    path('messageto/<int:id>', messageto, name='messageto'),
    path('purchase', purchase, name='purchase'),
    path('addsupplier', addsupplier, name='addsupplier'),
    path('cancelorder/<int:id>', cancelorder, name='cancelorder'),
    path('contactus', contactus, name='contactus'),
    path('adminmain', adminmain, name='adminmain'),
    path('promotion', promotion, name='promotion'),
    path('confirmpurchase', confirmpurchase, name='confirmpurchase'),
    path('purchasereceive/<id>', purchasereceive, name='purchasereceive'),
    path('purchasecancel/<int:id>', purchasecancel, name='purchasecancel'),

]