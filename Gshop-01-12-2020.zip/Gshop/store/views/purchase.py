from django.shortcuts import render , redirect , HttpResponseRedirect

from django.contrib.auth.hashers import  check_password
from store.models.customer import Customer
from django.views import  View
from store.models.forms import ProductForm
from store.models.product import Product
from store.models.category import Category
from store.models.supplier import Supplier
from store.models.tabletest import Tabletest
from store.models.stock import Stock
from store.models.supplierorder import SupplierOrder



def purchase(request):
    if request.method == "POST":
        n = SupplierOrder.objects.all().count()
        pnos = n + 1
        stocksave = Stock()
        stocksave.pno = pnos
        stocksave.supplier = request.POST['supplier']
        stocksave.maincategory = request.POST['maincategory']
        stocksave.subcategory = request.POST['subcategory']
        stocksave.subcategory2 = request.POST['subcategory2']
        stocksave.product = request.POST['product']
        stocksave.quantity = request.POST['quantity']
        stocksave.price = request.POST['price']
        stocksave.total = float(request.POST['quantity']) * float(request.POST['price'])
        stocksave.posted = "n"
        stocksave.save()
        suppliers = Supplier.objects.all()
        products = Product.objects.all()
        categories = Category.objects.all()
        stocks = Stock.objects.all()

        categoryfield1 = Tabletest.objects.values('category1').distinct()
        categoryfield2 = Tabletest.objects.values('category1', 'category2').distinct()
        categoryfield3 = Tabletest.objects.values('category2', 'category3').distinct()
        categoryfield4 = Tabletest.objects.values('category3', 'category4').distinct()

        data = {}

        data['stocks'] = stocks
        data['suppliers'] = suppliers
        data['products'] = products
        data['categories'] = categories
        data['categoryfield1'] = categoryfield1
        data['categoryfield2'] = categoryfield2
        data['categoryfield3'] = categoryfield3
        data['categoryfield4'] = categoryfield4
        data['pnos'] = pnos

        return render(request, 'purchase.html', data)

    else:
        n = SupplierOrder.objects.all().count()
        pnos = n + 1
        suppliers = Supplier.objects.all()
        products = Product.objects.all()
        categories = Category.objects.all()
        stocks = Stock.objects.all()

        categoryfield1 = Tabletest.objects.values('category1').distinct()
        categoryfield2 = Tabletest.objects.values('category1', 'category2').distinct()
        categoryfield3 = Tabletest.objects.values('category2', 'category3').distinct()
        categoryfield4 = Tabletest.objects.values('category3', 'category4').distinct()

        data = {}

        data['stocks'] = stocks
        data['suppliers'] = suppliers
        data['products'] = products
        data['categories'] = categories
        data['categoryfield1'] = categoryfield1
        data['categoryfield2'] = categoryfield2
        data['categoryfield3'] = categoryfield3
        data['categoryfield4'] = categoryfield4
        data['pnos'] = pnos

        return render(request, 'purchase.html', data)


def confirmpurchase(request):
    n = SupplierOrder.objects.all().count()
    pnos = n + 1
    supplierordersave = SupplierOrder()
    gt=0
    suppliername = ""
    for x in Stock.objects.all():
        if x.posted == "n":
            total = x.price * x.quantity
            gt=gt+total
            suppliername = x.supplier
            print(total)
            print(gt)
    supplierordersave.pno = pnos
    supplierordersave.name = suppliername
    supplierordersave.amount=gt
    supplierordersave.received="n"
    supplierordersave.save()

    for x in Stock.objects.all():
        if x.posted == "n":
            x.posted = "y"
            x.save()

    return render(request, 'index.html')


def purchasereceive(request, id):



    purchaseupdate = SupplierOrder.objects.get(pno=id)



    for m in Stock.objects.all():
        print('Yes : ', m.pno)
        if m.pno == id:
            print('Yes : ', m.product)
            for n in Product.objects.all():
                if m.product == n.name:
                    qtotal = m.quantity + n.quantity
                    n.quantity = qtotal
                    n.save()

    purchaseupdate.received = "y"
    purchaseupdate.save()
    return render(request, 'index.html')


def purchasecancel(request, id):
    purchaseupdate = SupplierOrder.objects.get(pno=id)
    purchaseupdate.received = "c"
    purchaseupdate.save()
    return render(request, 'index.html')

