from django.db import  models
from django.core.validators import MinLengthValidator

class SupplierOrder(models.Model):
    pno = models.CharField(max_length=50, null=True, blank=True)
    name = models.CharField(max_length=50, null=True, blank=True)
    amount = models.DecimalField(max_digits=10, decimal_places=3, default=0, null=True, blank=True)
    received = models.CharField(max_length=50, null=True, blank=True)


