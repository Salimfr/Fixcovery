from django.shortcuts import render, redirect

from django.contrib.auth.hashers import check_password
from store.models.customer import Customer
from django.views import View

from store.models.product import Product
from store.models.orders import Order
from store.middlewares.auth import auth_middleware
from store.models.ordermain import OrderMain
from store.models.tabletest import Tabletest

from django.shortcuts import render , redirect , HttpResponseRedirect
from store.models.product import Product
from store.models.category import Category
from django.views import View


def Test(request):

    categoryfield1 = Tabletest.objects.values('category1').distinct()

    categoryfield2 = Tabletest.objects.values('category1', 'category2').distinct()
    categoryfield3 = Tabletest.objects.values('category2', 'category3').distinct()
    categoryfield4 = Tabletest.objects.values('category3','category4').distinct()
    return render(request, 'test.html',{'categoryfield1': categoryfield1, 'categoryfield2': categoryfield2, 'categoryfield3': categoryfield3, 'categoryfield3': categoryfield3})

    cart = request.session.get('cart')
    if not cart:
        request.session['cart'] = {}
    products = None
    categories = Category.get_all_categories()
    categoryID = request.GET.get('category')
    if categoryID:
        products = Product.get_all_products_by_categoryid(categoryID)
    else:
        products = Product.get_all_products();

    data = {}
    data['products'] = products
    data['categories'] = categories

    return render(request, 'test.html',
                  {'categoryfield1': categoryfield1, 'categoryfield2': categoryfield2, 'categoryfield3': categoryfield3,
                   'categoryfield3': categoryfield3}, data)



def category2(request):
    categoryfield2 = Tabletest.objects.filter(category1="Alimentaire")
    print('ID == ',id)
    return render(request, 'test.html',{'categoryfield2': categoryfield2})