from django.shortcuts import render , redirect , HttpResponseRedirect
from store.models.product import Product
from store.models.category import Category
from store.models.tabletest import Tabletest
from django.views import View
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


# Create your views here.
class Index(View):

    def post(self , request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity<=1:
                        cart.pop(product)
                    else:
                        cart[product]  = quantity-1
                else:
                    cart[product]  = quantity+1

            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        print('cart' , request.session['cart'])
        return redirect('homepage')



    def get(self , request):
        # print()
        return HttpResponseRedirect(f'/store{request.get_full_path()[1:]}')

def promotion(request):
    cart = request.session.get('cart')
    if not cart:
        request.session['cart'] = {}
    products = None
    categories = Category.get_all_categories()
    categoryID = request.GET.get('category')
    if categoryID:
        products = Product.get_all_products_by_categoryid(categoryID)
    else:
        products = Product.get_all_products();



    categoryfield1 = Tabletest.objects.values('category1').distinct()
    categoryfield2 = Tabletest.objects.values('category1', 'category2').distinct()
    categoryfield3 = Tabletest.objects.values('category2', 'category3').distinct()
    categoryfield4 = Tabletest.objects.values('category3','category4').distinct()

    data = {}
    data['products'] = products
    data['categories'] = categories
    data['categoryfield1'] = categoryfield1
    data['categoryfield2'] = categoryfield2
    data['categoryfield3'] = categoryfield3
    data['categoryfield4'] = categoryfield4



    return render(request, 'promotion.html', data)
